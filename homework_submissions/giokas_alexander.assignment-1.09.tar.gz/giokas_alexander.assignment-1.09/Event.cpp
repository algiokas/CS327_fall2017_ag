#include "Event.h"
#include "Character.h"

Event::~Event()
{
}

