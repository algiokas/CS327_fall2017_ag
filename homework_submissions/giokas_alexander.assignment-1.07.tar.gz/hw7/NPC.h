#ifndef NPC_H

#define NPC_H

class Character;

class NPC :
	public Character
{
public:
	NPC();
	~NPC();
};

#endif

