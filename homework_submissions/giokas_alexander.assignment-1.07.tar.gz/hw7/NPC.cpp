#include "NPC.h"



NPC::NPC()
{
}


NPC::~NPC()
{
}
